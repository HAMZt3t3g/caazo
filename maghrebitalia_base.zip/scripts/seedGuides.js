
/**
 * seedGuides.js
 * Script Node per popolare Firestore con articoli demo.
 * USO:  node seedGuides.js
 * Pre‑requisito: impostare GOOGLE_APPLICATION_CREDENTIALS e iniziare Firebase Admin.
 */

import { initializeApp, applicationDefault } from 'firebase-admin/app';
import { getFirestore } from 'firebase-admin/firestore';
import { v4 as uuid } from 'uuid';
import fs from 'fs';

initializeApp({ credential: applicationDefault() });
const db = getFirestore();

const demo = JSON.parse(fs.readFileSync('./demoGuides.json'));

(async () => {
  for (const g of demo) {
    await db.collection('guides').doc(g.slug).set({
      ...g,
      publishedAt: new Date(),
    });
    console.log('Added', g.title);
  }
  process.exit(0);
})();
