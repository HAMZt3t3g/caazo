
// GuideOverview.jsx
import { Link } from 'react-router-dom';
import { cards } from '../data/guideCards';

/**
 * Overview delle categorie: mostra una card per ciascuna categoria.
 * L'intera card è cliccabile.
 */
export default function GuideOverview() {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 my-8">
      {cards.map(c => (
        <Link
          key={c.category}
          to={\`/guide/\${c.category}\`}
          className="block rounded-lg border p-6 hover:shadow-lg transition focus:outline-none focus:ring-2 focus:ring-green-600"
          aria-label={\`Apri guida \${c.title}\`}
        >
          <div className={\`flex items-center justify-center mb-4 h-12 w-12 rounded-full \${c.bg}\`}>
            {c.icon}
          </div>
          <h3 className="text-xl font-semibold mb-1">{c.title}</h3>
          <p className="text-sm text-gray-600">{c.description}</p>
          <span className="text-green-700 font-medium mt-4 inline-block">Scopri di più →</span>
        </Link>
      ))}
    </section>
  );
}
