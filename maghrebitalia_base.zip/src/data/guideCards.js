
// guideCards.js
// Definizione card categorie per GuideOverview

import { Briefcase, BookOpen, Heart, Languages, Globe, Building2 } from 'lucide-react';

export const cards = [
  {
    category: 'lavoro',
    title: 'Lavoro',
    description: 'Guide su opportunità di impiego, ricerca lavoro e ambiente professionale',
    bg: 'bg-blue-600 text-white',
    icon: <Briefcase size={24} />
  },
  {
    category: 'istruzione',
    title: 'Istruzione',
    description: 'Risorse per studio, scuola e formazione professionale',
    bg: 'bg-green-700 text-white',
    icon: <BookOpen size={24} />
  },
  {
    category: 'salute',
    title: 'Salute',
    description: 'Informazioni su assistenza sanitaria e benessere',
    bg: 'bg-red-600 text-white',
    icon: <Heart size={24} />
  },
  {
    category: 'lingua',
    title: 'Lingua',
    description: 'Materiali per imparare italiano e servizi di traduzione',
    bg: 'bg-yellow-500 text-white',
    icon: <Languages size={24} />
  },
  {
    category: 'cultura',
    title: 'Cultura',
    description: 'Iniziative culturali, vita sociale e integrazione',
    bg: 'bg-purple-600 text-white',
    icon: <Globe size={24} />
  },
  {
    category: 'servizi',
    title: 'Servizi',
    description: 'Orientamento a servizi pubblici, documenti e burocrazia',
    bg: 'bg-teal-600 text-white',
    icon: <Building2 size={24} />
  }
];
