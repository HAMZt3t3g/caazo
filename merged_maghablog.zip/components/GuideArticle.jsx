
// GuideArticle.jsx
import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import ReactMarkdown from 'react-markdown';

/**
 * Pagina articolo singolo.
 */
export default function GuideArticle() {
  const { slug } = useParams();
  const [guide, setGuide] = useState(null);

  useEffect(() => {
    const fetchGuide = async () => {
      const ref = doc(db, 'guides', slug);
      const snap = await getDoc(ref);
      if (snap.exists()) setGuide(snap.data());
    };
    fetchGuide();
  }, [slug]);

  if (!guide) return <p className="text-center py-10">Caricamento…</p>;

  return (
    <article className="prose lg:prose-lg mx-auto py-8">
      <h1>{guide.title}</h1>
      {guide.coverImage && (
        <img src={guide.coverImage} alt="" className="rounded-md" loading="lazy" />
      )}
      <ReactMarkdown>{guide.content}</ReactMarkdown>
    </article>
  );
}
