
// GuideList.jsx
import { useParams, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';

/**
 * Lista degli articoli per categoria.
 */
export default function GuideList() {
  const { category } = useParams();
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const q = query(collection(db, 'guides'), where('category', '==', category));
      const snap = await getDocs(q);
      setPosts(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    };
    fetchData();
  }, [category]);

  return (
    <div className="max-w-4xl mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6 capitalize">{category}</h1>
      <ul className="space-y-4">
        {posts.map(p => (
          <li key={p.id} className="border p-4 rounded-md hover:bg-gray-50">
            <Link to={\`/guide/\${category}/\${p.slug}\`} className="text-xl font-medium">
              {p.title}
            </Link>
            <p className="text-sm text-gray-600">{p.excerpt}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
