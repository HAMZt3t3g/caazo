import { useEffect } from 'react';

interface HistoryState {
  newsId?: string;
  previousPage?: string;
}

export const useHistory = (newsId: string | null, onClose: () => void) => {
  useEffect(() => {
    if (newsId) {
      // Push new state when opening article
      const state: HistoryState = { 
        newsId,
        previousPage: window.location.pathname 
      };
      window.history.pushState(state, '', `/news/${newsId}`);

      // Handle back button
      const handlePopState = () => {
        onClose();
      };

      window.addEventListener('popstate', handlePopState);
      return () => window.removeEventListener('popstate', handlePopState);
    }
  }, [newsId, onClose]);
};