import { useState, useEffect } from 'react';
import newsData from '../data/news.json';

interface NewsItem {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  imageUrl: string;
  category: string;
  author: string;
}

export function useNews() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      // Simulate API call
      setTimeout(() => {
        setNews(newsData.news);
        setLoading(false);
      }, 500);
    } catch (err) {
      setError('Errore nel caricamento delle notizie');
      setLoading(false);
    }
  }, []);

  return {
    news,
    loading,
    error
  };
}