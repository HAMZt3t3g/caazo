import { useState, useEffect } from 'react';
import eventsData from '../data/events.json';

export interface EventItem {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  time: string;
  location: string;
  imageUrl: string;
  category: string;
  organizer: string;
}

export function useEvents() {
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    try {
      // Simulate API call
      setTimeout(() => {
        setEvents(eventsData.events);
        setLoading(false);
      }, 500);
    } catch (err) {
      setError('Errore nel caricamento degli eventi');
      setLoading(false);
    }
  }, []);

  const addEvent = (newItem: Omit<EventItem, 'id'>) => {
    const id = (events.length + 1).toString();
    setEvents(prev => [...prev, { ...newItem, id }]);
  };

  const deleteEvent = (id: string) => {
    setEvents(prev => prev.filter(item => item.id !== id));
  };

  const updateEvent = (id: string, updatedItem: Partial<EventItem>) => {
    setEvents(prev => prev.map(item => 
      item.id === id ? { ...item, ...updatedItem } : item
    ));
  };

  return {
    events,
    loading,
    error,
    addEvent,
    deleteEvent,
    updateEvent
  };
}