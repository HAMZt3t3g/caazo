import { useEffect } from 'react';

declare global {
  interface Window { dataLayer: any[]; }
}

function App() {
  useEffect(() => {
    window.dataLayer = window.dataLayer || [];
    function gtag(){window.dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'GA_MEASUREMENT_ID');
  }, []);

  return (
    <div>
      {/* Your existing app content */}
    </div>
  );
}

export default App;