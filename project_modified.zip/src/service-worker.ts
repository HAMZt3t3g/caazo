self.addEventListener('install', (event) => {
  console.log('Service Worker install');
});
self.addEventListener('fetch', (event) => {
  event.respondWith(fetch(event.request));
});